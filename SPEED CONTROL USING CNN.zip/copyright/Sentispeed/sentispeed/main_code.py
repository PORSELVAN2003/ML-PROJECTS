import cv2
import numpy as np
import time
import pygame
import pywhatkit as pyw
import datetime
import pytz
import geocoder
from keras.models import model_from_json
from pygame import mixer
import control as cn


pygame.init()
mixer.init()
path_emotion_model = 'path of json model'
path_model_h5 = 'path of h5 model'
json_file = open(path_emotion_model)
model_json = json_file.read()
json_file.close()
model = model_from_json(model_json)
model.load_weights(path_model_h5)


webcam = cv2.VideoCapture(1) # if it not works use this cv2.VideoCapture(1)


face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_eye.xml')
recipient_phone_number = '+91720xxxxxxx'
labels = {0: 'angry', 1: 'disgust', 2: 'fear', 3: 'happy', 4: 'neutral', 5: 'sad', 6: 'surprise'}


music_mapping = {
    0: 'path of the music angry',
    1: 'path of the music disgust',
    2: 'path of the music fear',
    3: 'path of the music happy',
    4: 'path of the music neutral',
    5: 'path of the music sad',
    6: 'path of the music surprise'
}


sound = mixer.Sound('alarm.wav')
def send_whatsapp_message(recipient_phone_number, message_content):
    try:        
        local_timezone = pytz.timezone('Asia/Kolkata')
        current_time = datetime.datetime.now(local_timezone).time()       
        pyw.sendwhatmsg(recipient_phone_number, message_content, current_time.hour, current_time.minute + 1)
        print(f"WhatsApp message sent at {current_time} to {recipient_phone_number}: {message_content}")
    except Exception as e:
        print("Error sending WhatsApp message:", str(e))
def play_music(file):
    mixer.music.stop()
    mixer.music.load(file)
    mixer.music.play()
def extract_features(image):
    feature = np.array(image)
    feature = feature.reshape(1,48,48,1)
    return feature/255.0
def get_current_location():
    try:
        g = geocoder.ip('me')
        return g.city
    except Exception as e:
        print("Error fetching location:", str(e))
        return "Unknown"
score = 0
last_eye_open_time = 0
eye_closed_duration = 0
last_prediction_time = time.time()
while True:
    ret, frame = webcam.read()
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.1, 5)

    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), thickness=3)
        image = gray[y:y + h, x:x + w]
        image = cv2.resize(image, (48, 48))
        img = extract_features(image)
        pred = model.predict(img)
        prediction_label = labels[pred.argmax()]
        current_time = time.time()
        if current_time - last_prediction_time >= 5:
            cv2.putText(frame, '%s' % (prediction_label), (x-10, y-10), cv2.FONT_HERSHEY_COMPLEX_SMALL, 2, (0, 0, 255))
            last_prediction_time = current_time
            print(prediction_label)
            cn.predicted_label(prediction_label)
            music_file = music_mapping.get(pred.argmax())
            play_music(music_file)
        eyes = eye_cascade.detectMultiScale(image)
        if len(eyes) == 0:
            current_time = time.time()
            if last_eye_open_time == 0:
                last_eye_open_time = current_time
            else:
                eye_closed_duration = current_time - last_eye_open_time
        else:
            last_eye_open_time = 0
            eye_closed_duration = 0

        if eye_closed_duration > 5:  
            current_location = get_current_location()
            message_content = f"Driver is drowsy at {current_location}."
            send_whatsapp_message(recipient_phone_number, message_content)
            sound.play()

    cv2.putText(frame, "Eye Closed Duration: " + str(eye_closed_duration), (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
    cv2.imshow("Frame", frame)

    if cv2.waitKey(1) == 13:
        break

# Release resources
webcam.release()
cv2.destroyAllWindows()
pygame.quit()
