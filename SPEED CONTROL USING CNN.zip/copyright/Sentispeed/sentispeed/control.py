from pyfirmata import Arduino
import pyfirmata
import time

en1_pin = 6
led_happy_pin = 12
led_neutral_pin = 11
led_other_emotions_pin = 13
green_led_pin = 9 
yellow_led_pin = 10  
red_led_pin = 8  

board = Arduino('COM7')

board.digital[en1_pin].mode = pyfirmata.PWM
board.digital[led_happy_pin].mode = pyfirmata.OUTPUT
board.digital[led_neutral_pin].mode = pyfirmata.OUTPUT
board.digital[led_other_emotions_pin].mode = pyfirmata.OUTPUT
board.digital[green_led_pin].mode = pyfirmata.OUTPUT 
board.digital[yellow_led_pin].mode = pyfirmata.OUTPUT  
board.digital[red_led_pin].mode = pyfirmata.OUTPUT  
def set_motor_speed(speed):
    board.digital[en1_pin].write(speed / 255)

def predicted_label(label):
    
    board.digital[led_happy_pin].write(0)
    board.digital[led_neutral_pin].write(0)
    board.digital[led_other_emotions_pin].write(0)
    board.digital[green_led_pin].write(0)  
    board.digital[yellow_led_pin].write(0)  
    board.digital[red_led_pin].write(0)  
    
    if label == "happy":
        set_motor_speed(200)
        set_motor_speed(150)
        set_motor_speed(100)
        board.digital[led_happy_pin].write(1)
        board.digital[yellow_led_pin].write(1)   
    elif label == "neutral":
        set_motor_speed(200)
        board.digital[led_neutral_pin].write(1)
        board.digital[green_led_pin].write(1)  
    else:
        set_motor_speed(200)
        set_motor_speed(150)
        set_motor_speed(100)
        set_motor_speed(50)
        set_motor_speed(0)
        board.digital[led_other_emotions_pin].write(1)
        board.digital[red_led_pin].write(1)